package utils;

public class Links {

    public static String HOME = "http://parabank.parasoft.com/parabank/index.html";
}
